function demoExternalAlert(){
    alert("Internal Alert.");
   }
   function demoExternalConfirm(){
    confirm("Internal Confirm.");
   }
   function demoExternalPromt(){
    prompt("Internal Promt.");
   }
   function changeColor(){
      document.body.style.backgroundColor="Pink";
   }
   function divChangeColor(){
       document.getElementById("D1").style.backgroundColor="yellow";
   }
   function divBGDynamic(){
    document.getElementById("D1").style.backgroundColor=prompt("Enter color name");
   }
   function bodyBGDynamic(){
    document.body.style.backgroundColor=prompt("Enter color name");
   }
   function bodyBGCP1(){
    document.body.style.backgroundColor=document.getElementById("CP1").value;
   }
   function divBGCP2(){
    document.getElementById("D1").style.backgroundColor=document.getElementById("CP2").value;
   }